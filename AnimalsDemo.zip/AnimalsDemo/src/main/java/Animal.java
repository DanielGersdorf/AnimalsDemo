public class Animal {

}
